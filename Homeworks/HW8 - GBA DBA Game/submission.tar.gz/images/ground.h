/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x24 ground ground.png 
 * Time-stamp: Friday 04/03/2020, 01:29:53
 * 
 * Image Information
 * -----------------
 * ground.png 240@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GROUND_H
#define GROUND_H

extern const unsigned short ground[5760];
#define GROUND_SIZE 11520
#define GROUND_LENGTH 5760
#define GROUND_WIDTH 240
#define GROUND_HEIGHT 24

#endif

