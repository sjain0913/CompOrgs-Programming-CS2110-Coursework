/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=45x89 tower3 tower3.png 
 * Time-stamp: Friday 04/03/2020, 10:17:41
 * 
 * Image Information
 * -----------------
 * tower3.png 45@89
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TOWER3_H
#define TOWER3_H

extern const unsigned short tower3[4005];
#define TOWER3_SIZE 8010
#define TOWER3_LENGTH 4005
#define TOWER3_WIDTH 45
#define TOWER3_HEIGHT 89

#endif

