/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=26x26 buzz buzz.png 
 * Time-stamp: Friday 04/03/2020, 09:51:54
 * 
 * Image Information
 * -----------------
 * buzz.png 26@26
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BUZZ_H
#define BUZZ_H

extern const unsigned short buzz[676];
#define BUZZ_SIZE 1352
#define BUZZ_LENGTH 676
#define BUZZ_WIDTH 26
#define BUZZ_HEIGHT 26

#endif

