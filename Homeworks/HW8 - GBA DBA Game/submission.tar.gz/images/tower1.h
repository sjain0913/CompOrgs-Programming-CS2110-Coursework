/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=34x68 tower1 tower1.png 
 * Time-stamp: Friday 04/03/2020, 08:38:56
 * 
 * Image Information
 * -----------------
 * tower1.png 34@68
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TOWER1_H
#define TOWER1_H

extern const unsigned short tower1[2312];
#define TOWER1_SIZE 4624
#define TOWER1_LENGTH 2312
#define TOWER1_WIDTH 34
#define TOWER1_HEIGHT 68

#endif

