/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x80 tower2 tower2.png 
 * Time-stamp: Friday 04/03/2020, 08:39:08
 * 
 * Image Information
 * -----------------
 * tower2.png 40@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TOWER2_H
#define TOWER2_H

extern const unsigned short tower2[3200];
#define TOWER2_SIZE 6400
#define TOWER2_LENGTH 3200
#define TOWER2_WIDTH 40
#define TOWER2_HEIGHT 80

#endif

